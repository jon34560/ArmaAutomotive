#include <atmel_start.h>

//#include <avrlibdefs.h>
#include <avrlibtypes.h>
#include <util/delay.h>
//#include <defines.h>
#include <serial.h>
#include <serial_communication.h>
#include <timers.h>
#include <adc.h>
#include <MCP41x.h>

int main(void)
{
/* Initializes MCU, drivers and middleware */
	
	atmel_start_init();
	ADC_Init();
	serial_init();
	timers_init();
	SPI_Init();
	MCP41x_Init(100000,125);  //MCP41x_Init(max value of digital pot in ohm "10k, 50 k, 100 k" , RW "Wiper Resistance" for the value in ohm see datasheet )
	MCP41x_Set_Vlaue(100000,1); //MCP41x_Set_Vlaue(the desired value in ohm, the concerned side  RA or RB)
	
	sei();
	
	while (1) {
		if (SENS1_get_level() && LT_delay == 0) { //Left turn
			LT_delay = 18; //288 ms
			if (TCCR0 == 0) timer0_init();
			
			if (car_data[7]) {
				car_data[7] = 0;
				LT_set_level (0);
				LRT_periods = 0;
			}
			else {
				car_data[7] = 1;
				RT_set_level (0);
				LT_set_level (1);
				car_data[8] = 0;
				LRT_periods = 15;
			}
		}
		else if (SENS2_get_level() && RT_delay == 0) { //Right turn
			RT_delay = 18; //288 ms
			if (TCCR0 == 0) timer0_init();
			
			if (car_data[8]) {
				car_data[8] = 0;
				RT_set_level (0);
				LRT_periods = 0;
			}
			else {
				car_data[8] = 1;
				LT_set_level (0);
				RT_set_level (1);
				car_data[7] = 0;
				LRT_periods = 15;
			}
		}
		else if (SENS3_get_level() && RB_get_level() == 0) {	//Brake ON
			RB_set_level(1);
			car_data[5] = 1;
		}
		else if (SENS3_get_level() == 0 && RB_get_level()) {	//Brake OFF
			RB_set_level(0);
			car_data[5] = 0;
		}
		else if (SENS4_get_level() && DRV4_get_level() == 0) {	//Horn ON
			DRV4_set_level(1);
		}
		else if (SENS4_get_level() == 0 && DRV4_get_level()) {	//Horn OFF
			DRV4_set_level(0);
		}
		else if (SENS5_get_level() && beam_delay == 0) {	//high-beam
			PWM2_toggle_level();
			beam_delay = 18; //288 ms
			if (TCCR0 == 0) timer0_init();
		}
		else if (SENS6_get_level()) {	//Right wight
			
		}
		else if (SENS7_get_level() && SENS8_get_level() ==0 && LW_INH_get_level() == 0) {	//LW UP ON
			LW_HIGH_set_level(1);
			LW_LOW_set_level(0);
			LW_INH_set_level(1);
		}
		else if (SENS7_get_level() == 0 && LW_HIGH_get_level() && LW_periods == 0) {	//LW UP OFF
			LW_HIGH_set_level(0);
			LW_LOW_set_level(0);
			LW_INH_set_level(0);
		}
		else if (SENS8_get_level() && SENS7_get_level() == 0 && LW_INH_get_level() == 0) {	//LW DOWN ON
			LW_HIGH_set_level(0);
			LW_LOW_set_level(1);
			LW_INH_set_level(1);
		}
		else if (SENS8_get_level() == 0 && LW_LOW_get_level() && LW_periods == 0) {	//LW DOWN OFF
			LW_HIGH_set_level(0);
			LW_LOW_set_level(0);
			LW_INH_set_level(0);
		}
		else if (SENS9_get_level() && SENS10_get_level() == 0 && RW_INH_get_level() == 0) {	//RW UP ON
			RW_HIGH_set_level(1);
			RW_LOW_set_level(0);
			RW_INH_set_level(1);
		}
		else if (SENS9_get_level() == 0 && RW_HIGH_get_level() && RW_periods == 0) {	//RW UP OFF
			RW_HIGH_set_level(0);
			RW_LOW_set_level(0);
			RW_INH_set_level(0);
		}
		else if (SENS10_get_level() && SENS9_get_level() == 0 && RW_INH_get_level() == 0) {	//RW DOWN ON
			RW_HIGH_set_level(0);
			RW_LOW_set_level(1);
			RW_INH_set_level(1);
		}
		else if (SENS10_get_level() == 0 && RW_LOW_get_level() && RW_periods == 0) {	//RW DOWN OFF
			RW_HIGH_set_level(0);
			RW_LOW_set_level(0);
			RW_INH_set_level(0);
		}
		else if (SENS11_get_level() && Hz_delay == 0) { //Hazard
			Hz_delay = 18; //288 ms
			if (TCCR0 == 0) timer0_init();
			
			if (car_data[6]) {
				car_data[6] = 0;
				LT_set_level (0);
				RT_set_level (0);
				LRT_periods = 0;
			}
			else {
				car_data[6] = 1;
				LT_set_level (1);
				RT_set_level (1);
				LRT_periods = 15;
			}
			//RT_toggle_level();
			//_delay_ms(300);
			
		}
		else {
			parcer();
		}
			
		if (LRT_periods == 0){
			if (car_data[6] ) {	//hazard
				LT_toggle_level();
				RT_toggle_level();
				LRT_periods = 15;
				if (TCCR0 == 0) timer0_init();
			}
			else if (car_data[7] ) {	//left_turn_signal
				LT_toggle_level();
				LRT_periods = 15;
				if (TCCR0 == 0) timer0_init();
			}
			else if (car_data[8] ) {	//right_turn_signal
				RT_toggle_level();
				LRT_periods = 15;
				if (TCCR0 == 0) timer0_init();
			}
		}
		if (L1_periods == 0 && DRV31_get_level()){
			DRV31_set_level(0);
		}
		if (L2_periods == 0 && DRV32_get_level()){
			DRV32_set_level(0);
		}
		if (L3_periods == 0 && DRV33_get_level()){
			DRV33_set_level(0);
		}
		if (L4_periods == 0 && DRV34_get_level()){
			DRV34_set_level(0);
		}
	}
	
	
}
