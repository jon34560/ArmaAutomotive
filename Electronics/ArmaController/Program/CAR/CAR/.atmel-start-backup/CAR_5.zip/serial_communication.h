/*
 * serial_communication.h
 *
 * Created: 31.03.2019 3:14:49
 *  Author: RUSLAN
 */ 


#ifndef SERIAL_COMMUNICATION_H_
#define SERIAL_COMMUNICATION_H_

void parcer();


#endif /* SERIAL_COMMUNICATION_H_ */