/*
 * adc.h
 *
 * Created: 07.04.2019 14:45:51
 *  Author: RUSLAN
 */ 


#ifndef ADC_H_
#define ADC_H_

void ADC_Init(void);




#endif /* ADC_H_ */