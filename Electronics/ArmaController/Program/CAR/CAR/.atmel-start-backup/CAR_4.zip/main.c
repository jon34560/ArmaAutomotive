#include <atmel_start.h>

//#include <avrlibdefs.h>
#include <avrlibtypes.h>
#include <util/delay.h>
//#include <defines.h>
#include <serial.h>
#include <serial_communication.h>
#include <timers.h>
#include <adc.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	serial_init();
	timers_init();
	
	sei();
	
	while (1) {
		if (SENS1_get_level()) {
			LT_toggle_level();
			_delay_ms(300);
		}
		else if (SENS2_get_level()) {
			RT_toggle_level();
			_delay_ms(300);
		}
		else if (SENS3_get_level()) {
		
		}
		else if (SENS4_get_level()) {
			
		}
		else if (SENS5_get_level()) {
			
		}
		else if (SENS6_get_level()) {
			
		}
		else if (SENS7_get_level()) {
			
		}
		else if (SENS8_get_level()) {
			
		}
		else if (SENS9_get_level()) {
			
		}
		else if (SENS10_get_level()) {
			
		}
		else if (SENS11_get_level()) {
			
		}
		else {
			parcer();
		}
			
	}
}
