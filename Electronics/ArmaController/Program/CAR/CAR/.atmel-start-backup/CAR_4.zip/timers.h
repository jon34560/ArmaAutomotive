/*
 * timers.h
 *
 * Created: 07.04.2019 11:33:16
 *  Author: RUSLAN
 */ 


#ifndef TIMERS_H_
#define TIMERS_H_

void timers_init();



#endif /* TIMERS_H_ */