/*
 * adc.c
 *
 * Created: 07.04.2019 14:45:27
 *  Author: RUSLAN
 */ 


#include <atmel_start.h>


////////////////ADC0 channel input initialization//////////////
//
// Config. the ADC to take input from channel 0:
// * Reference: Aref
// * Channel: 0
// * ADC clock: 16MHz/128 = 125KHz
// * Mode: single conversion
// * Result justification: right adjusted
//
//////////////////////////////////////////////////////////////
void ADC_Init(void)
{
			//ADEN: ADC Enable
			//ADSC: ADC Start Conversion
			//ADIE: ADC Interrupt Enable
			//ADPS2:0: ADC Prescaler Select Bits (Division Factor=128)
	ADCSRA = (1<<ADEN)|(1<<ADSC)|(1<<ADIE)|(1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0);
}