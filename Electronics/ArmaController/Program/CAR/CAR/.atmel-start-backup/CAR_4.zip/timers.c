/*
 * timers.c
 *
 * Created: 07.04.2019 11:32:59
 *  Author: RUSLAN
 */ 

#include <atmel_start.h>

ISR(TIMER1_OVF_vect)	//���������� ��� ���������� ��������� 0b000.
{

}

///////////////Fast PWM mode initialization////////////////////
//
// Config. Timer/Counter1 to work in fast PWM mode:
// * Frequency: 16MHz/1024 = 15.625KHz
// * Resolution: 10 bit (top value = 0x03FF)
//
///////////////////////////////////////////////////////////////

void timers_init()
{
// Use fixed top value 0x03FF (WGM13:WGM10 = 0b0111)
// No Prescaling (CS12:CS10 = 0b001)
TCCR1A = (1<<COM1A1)|(1<<WGM11)|(1<<WGM10);
TCCR1B = (1<<WGM12)|(1<<CS10);
OCR1A = 512;   // OUT initially 50%
//TIMSK = 1<<TOIE1; // Enable overflow interrupt

}