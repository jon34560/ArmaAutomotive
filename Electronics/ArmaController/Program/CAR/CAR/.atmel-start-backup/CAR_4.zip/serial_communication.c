/*
 * serial_communication.c
 *
 * Created: 31.03.2019 3:14:33
 *  Author: RUSLAN
 */ 


#include "serial_communication.h"
#include <atmel_start.h>
#include <avr/pgmspace.h>
#include <string.h>
#include <defines.h>
#include <serial.h>

//int nums=0;
int counter=0;
int digits=0;

void parcer()
{
	if (rx_flag) {
		rx_flag = 0;
		//buffer_digits[0]=0;
		//SendStr(_rx_buffer);
		//while (tx_flag == 0);
		//tx_flag = 0;
		int nums = 0;
		
		
		while (0 != strcmp(_rx_buffer, strcpy_P(queue, (PGM_P)pgm_read_word(&(InputStringPointers[nums])))) && nums < 19) nums++;
		
		switch (nums) {
			case 0:		//get
			counter = 0;
			tx_flag = 1;
			break;
			case 1:		//setInteriorLightsOn
				PWM5_set_level (1);
				car_data[9] = 1;
			break;
			case 2:		//setInteriorLightsOff
				PWM5_set_level (0);
				car_data[9] = 0;
			break;
			case 3:		//activateHighBeam
	
	
			break;
			case 4:		//deactivateHighBeam
	
	
			break;
			case 5:		//activateFutureUse
				PWM6_set_level (1);
	
			break;
			case 6:		//deactivateFutureUse
				PWM6_set_level (0);
	
			break;
			case 7:		//activateLeftWindowUp
	
	
			break;
			case 8:		//activateLeftWindowDown
	
	
			break;
			case 9:		//activateRightWindowUp
	
			break;
			case 10:	//activateRightWindowDown
	
			break;
			case 11:	//activateWindshieldWiper1
				
			break;
			case 12:	//activateWindshieldWiper2
				
			break;
			case 13:	//activateWindshieldWiper3
				
			break;
			case 14:	//deactivateWindshieldWiper
				
			break;
			case 15:	//activateDoorLatch1
			
			break;
			case 16:	//activateDoorLatch2
			
			break;
			case 17:	//activateDoorLatch3
				
			break;
			case 18:	//activateDoorLatch4
			
			break;
			default:
			    digits=0;
				for (unsigned char i = 0; i < _rx_buffer_tail; i++){
					if (_rx_buffer[i] >= 0x30 && _rx_buffer[i] <= 0x39){
						digits = digits + (_rx_buffer[i] & 0x0F);
						digits = digits * 10;
						_rx_buffer[i] = 0;
					};
				};
				digits = digits / 10;
				nums = 19;
				while (0 != strcmp(_rx_buffer, strcpy_P(queue, (PGM_P)pgm_read_word(&(InputStringPointers[nums]))))) {
					nums++;
					if (nums > 21) break;
				};
				
			
				if (nums == 19) {		//setLightsLevel
					
				}
				else if	(nums == 20) {	//setVentsLevel
					car_data[11] = digits;
				}
				else if	(nums == 21) {	//setSteeringAssist
					car_data[18] = digits;
				}
		}
		memset(_rx_buffer, 0, _rx_buffer_tail);
		_rx_buffer_head = 0;
		_rx_buffer_tail = 0;
	}
	else if (tx_flag) {
			tx_flag = 0;
			if (counter != 19) {
				utoa(car_data[counter], buffer_digits, 10);
				SendStr(strcpy_P(_tx_buffer, (PGM_P)pgm_read_word(&(VariablePointers[counter]))));
				counter++;
			}
	}

}